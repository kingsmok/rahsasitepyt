# -*- coding: utf-8 -*-
"""آکادمی آنلاین — اسکریپت LMS آموزشی با Flask
اجرا:  python seed.py  (بار اول)
      python app.py   (شروع سرور)
"""
import os
from datetime import datetime
try:
    from datetime import UTC
except ImportError:  # پایتون < 3.11 (هاست‌های اشتراکی)
    from datetime import timezone as _tz_utc
    UTC = _tz_utc.utc

# بارگذاری .env در صورت وجود (python-dotenv)
try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:
    pass

from flask import Flask, g, request, session, redirect, url_for, abort, render_template
from models import utcnow, db, User, Setting, Category, Order, NewsletterEmail
from jdates import (fa, fa_num, money, MONTHS, slugify, jdate, jdatetime, jdate_num, jtime,
                  jalali_to_gregorian, g2j, j2g)
from validators import log_exc as _lexc

# ------------------------------------------------------------------
# تم‌های ۲۰‌گانه
# ------------------------------------------------------------------
THEMES = [
    dict(id='theme-01', name='آبی کلاسیک',  desc='تم کلاسیک و حرفه‌ای با رنگ آبی رسمی',  colors=['#2563eb', '#1d4ed8', '#f59e0b'], dark=False),
    dict(id='theme-02', name='بنفش مدرن',   desc='بنفش سلطنتی با حال‌وهوای مدرن',       colors=['#7c3aed', '#6d28d9', '#22d3ee'], dark=False),
    dict(id='theme-03', name='سبز زمردی',   desc='سبز زمردی آرامش‌بخش و الهام‌بخش',     colors=['#059669', '#047857', '#fbbf24'], dark=False),
    dict(id='theme-04', name='سرخ یاقوتی',  desc='قرمز پرانرژی برای برندهای پرشور',     colors=['#dc2626', '#b91c1c', '#fbbf24'], dark=False),
    dict(id='theme-05', name='نارنجی آفتابی', desc='نارنجی گرم و پرانرژی',              colors=['#ea580c', '#c2410c', '#22c55e'], dark=False),
    dict(id='theme-06', name='رز گلد',      desc='صورتی‌طلایی لوکس و جذاب',            colors=['#e11d63', '#be185d', '#f59e0b'], dark=False),
    dict(id='theme-07', name='فیروزه‌ای',   desc='فیروزه‌ای تازه و آرامش‌بخش',          colors=['#0d9488', '#0f766e', '#f59e0b'], dark=False),
    dict(id='theme-08', name='نیمه‌شب',     desc='تم تیره با آبی روشن — مناسب نمایشگر OLED', colors=['#0ea5e9', '#0284c7', '#f59e0b'], dark=True),
    dict(id='theme-09', name='مشکی طلایی',  desc='لوکس و شیک — مشکی با طلایی',          colors=['#f59e0b', '#d97706', '#fbbf24'], dark=True),
    dict(id='theme-10', name='طوسی مینیمال', desc='مینیمال و ساده با طوسی خنثی',        colors=['#475569', '#334155', '#0ea5e9'], dark=False),
    dict(id='theme-11', name='کاربن',       desc='تم تیره مدرن با سبز نئون',            colors=['#34d399', '#10b981', '#a3e635'], dark=True),
    dict(id='theme-12', name='لیمویی',      desc='سبز لیمویی شاد و پرانرژی',            colors=['#65a30d', '#4d7c0f', '#f97316'], dark=False),
    dict(id='theme-13', name='اقیانوس',     desc='آبی اقیانوسی با گرادیان عمیق',        colors=['#0284c7', '#0369a1', '#38bdf8'], dark=False),
    dict(id='theme-14', name='کهکشان',      desc='بنفش کهکشانی تیره با ستاره‌ها',       colors=['#a855f7', '#7e22ce', '#f0abfc'], dark=True),
    dict(id='theme-15', name='فلامینگو',    desc='صورتی شاد و محبوب مخاطبان جوان',      colors=['#ec4899', '#db2777', '#8b5cf6'], dark=False),
    dict(id='theme-16', name='قهوه‌ای گرم',  desc='قهوه‌ای گرم و صمیمی',                colors=['#92400e', '#78350f', '#f59e0b'], dark=False),
    dict(id='theme-17', name='شرابی',       desc='شرابی کلاسیک و رسمی',                colors=['#9f1239', '#881337', '#f59e0b'], dark=False),
    dict(id='theme-18', name='نعنایی روشن', desc='روشن و شاد با سبز نعنایی',            colors=['#10b981', '#059669', '#f472b6'], dark=False),
    dict(id='theme-19', name='سرمه سلطنتی', desc='سرمه‌ای عمیق و باوقار',               colors=['#1e3a8a', '#1e40af', '#f59e0b'], dark=False),
    dict(id='theme-20', name='رنگین‌کمان',   desc='چند‌رنگ شاد با گرادیان‌های رنگی',     colors=['#6366f1', '#ec4899', '#f59e0b'], dark=False),
    dict(id='theme-21', name='ایرانی',       desc='فیروزه‌ای و لاجورد با نقوش اسلیمی و گره‌چینی', colors=['#0e9488', '#d4a017', '#0f3a4e'], dark=False),
    dict(id='theme-22', name='فرادرس',       desc='سرمه‌ای و نارنجی — منو و فوتر به سبک فرادرس', colors=['#f2640c', '#0f2744', '#ff7a1a'], dark=False),
    dict(id='theme-23', name='فیروزه',       desc='کاشی فیروزه‌ای ایرانی — آرام، آکادمیک و متمایز با زعفران', colors=['#0f766e', '#b45309', '#134e4a'], dark=False),
]

# ============================================================
# ۲۰ طرح اختصاصی ایرانی — از persian_themes.py
# ============================================================
from persian_themes import PERSIAN_THEMES as _PERSIAN_THEMES
# مدل‌های زیرساختی (BNPL/Cashback/مارکت‌پلیس/گردونه/قیمت) — برای ساخت جدول‌ها
import ext_models  # noqa: F401
THEMES.extend(dict(id=t['id'], name=t['name'],
                   desc=f"{t['desc']} — {t['category']}",
                   colors=[t['colors']['primary'], t['colors']['accent'], t['colors']['secondary']],
                   dark=t.get('dark', False), persian=True)
              for t in _PERSIAN_THEMES)
VALID_THEMES = [t['id'] for t in THEMES]

# ------------------------------------------------------------------
# ساخت اپلیکیشن
# ------------------------------------------------------------------
def create_app():
    app = Flask(__name__)
    # ---------- لاگ ساختاریافته: کنسول + فایل چرخشی ----------
    import logging as _logging
    from logging.handlers import RotatingFileHandler as _RFH
    _log_dir = os.environ.get('LOG_DIR') or os.path.join(os.path.dirname(os.path.abspath(__file__)), 'logs')
    os.makedirs(_log_dir, exist_ok=True)
    _fmt = _logging.Formatter('%(asctime)s | %(levelname)s | %(name)s | %(message)s')
    _fh = _RFH(os.path.join(_log_dir, 'academy.log'), maxBytes=5 * 1024 * 1024, backupCount=5, encoding='utf-8')
    _fh.setFormatter(_fmt)
    _ch = _logging.StreamHandler()
    _ch.setFormatter(_fmt)
    _root = _logging.getLogger()
    _root.setLevel(_logging.INFO)
    if not any(isinstance(h, _RFH) for h in _root.handlers):
        _root.addHandler(_fh)
        _root.addHandler(_ch)
    app.logger.setLevel(_logging.INFO)
    app.logger.info('app initialized (log_dir=%s)', _log_dir)
    # کلید امنیتی: در پروداکشن حتماً باید از محیط تنظیم شود (جلوگیری از جعل session)
    app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY')
    if not app.config['SECRET_KEY']:
        if os.environ.get('FLASK_ENV') == 'production' or os.environ.get('APP_ENV') == 'production':
            raise RuntimeError('SECRET_KEY باید در محیط production تنظیم شود! (متغیر محیطی SECRET_KEY)')
        app.config['SECRET_KEY'] = 'dev-only-key-1403-change-in-production'
    app.config['PERMANENT_SESSION_LIFETIME'] = 60 * 60 * 24 * 30  # ۳۰ روز
    app.config['SESSION_COOKIE_HTTPONLY'] = True
    app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
    # کوکی فقط روی HTTPS — در production اجباری
    app.config['SESSION_COOKIE_SECURE'] = os.environ.get('SESSION_COOKIE_SECURE', '0') == '1' or \
        os.environ.get('FLASK_ENV') == 'production' or os.environ.get('APP_ENV') == 'production'
    # محدودیت حجم بدنه/آپلود: ۵۰ مگابایت
    app.config['MAX_CONTENT_LENGTH'] = int(os.environ.get('MAX_CONTENT_LENGTH', 50 * 1024 * 1024))
    # دیتابیس: SQLite محلی (پیش‌فرض) یا MySQL با DATABASE_URL
    #   DATABASE_URL=mysql+pymysql://USER:PASS@HOST:3306/DBNAME?charset=utf8mb4
    _db_url = os.environ.get('DATABASE_URL') or ''
    if _db_url.startswith('mysql'):
        # اطمینان از utf8mb4 (فارسی + ایموجی) و راننده pymysql
        if 'charset=' not in _db_url:
            _db_url += ('&' if '?' in _db_url else '?') + 'charset=utf8mb4'
        # pool_pre_ping: جلوگیری از قطعی اتصال در هاست‌های اشتراکی (MySQL timeout)
        app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {'pool_pre_ping': True, 'pool_recycle': 280}
    app.config['SQLALCHEMY_DATABASE_URI'] = _db_url or \
        'sqlite:///' + os.path.join(app.instance_path, 'academy.db')
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    os.makedirs(app.instance_path, exist_ok=True)
    db.init_app(app)
    # ساخت خودکار جدول‌ها در اولین اجرا (SQLite تازه یا MySQL خالی)
    # — idempotent است: فقط جدول‌های موجود را بررسی و ایجاد می‌کند
    try:
        with app.app_context():
            db.create_all()
    except Exception:
        _lexc('app.py')

    # ---------- فیلترها ----------
    app.jinja_env.filters['fa'] = fa
    app.jinja_env.filters['money'] = money
    app.jinja_env.filters['jdate'] = jdate
    app.jinja_env.filters['jdatetime'] = jdatetime
    app.jinja_env.filters['jdate_num'] = jdate_num
    app.jinja_env.filters['jtime'] = jtime
    app.jinja_env.filters['slugify'] = slugify

    def _from_json(v):
        import json as _json
        try:
            return _json.loads(v or '{}')
        except Exception:
            return {}
    app.jinja_env.filters['from_json'] = _from_json
    from validators import mask_nc
    app.jinja_env.filters['mask_nc'] = mask_nc
    # نسخه خودکار assetها — از آخرین زمان تغییر فایل‌های static (برای شکستن کش)
    def _asset_v():
        try:
            import os as _os
            base = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), 'static')
            latest = 0.0
            for root, _dirs, files in _os.walk(base):
                for fn in files:
                    try:
                        latest = max(latest, _os.path.getmtime(_os.path.join(root, fn)))
                    except OSError:
                        pass
            return str(int(latest))
        except Exception:
            return '1'
    app.jinja_env.globals['asset_v'] = _asset_v
    app.jinja_env.globals.update(THEMES=THEMES, fa=fa, money=money,
                                 PERSIAN_THEMES=_PERSIAN_THEMES)

    # آمار واقعی سایت — با کش کوتاه (۳۰ ثانیه) برای نمایش در قالب‌ها/ویجت‌ها
    _stats_cache = {'t': 0, 'data': {}}
    def site_stats():
        import time as _time
        now = _time.time()
        if now - _stats_cache['t'] < 30 and _stats_cache['data']:
            return _stats_cache['data']
        try:
            from models import (User as _U, Course as _C, Lesson as _L, Section as _S,
                                Review as _R, Enrollment as _E, BlogPost as _B,
                                SuccessStory as _SS)
            _avg_rating = db.session.query(db.func.avg(_R.rating)).filter(_R.is_approved == True).scalar() or 0
            st = dict(
                students=_U.query.filter_by(role='student').count(),
                users=_U.query.count(),
                teachers=_U.query.filter(_U.role.in_(['teacher', 'admin'])).count(),
                courses=_C.query.filter_by(status='published').count(),
                lessons=_L.query.count(),
                hours=int(sum((c.duration_hours or 0) for c in _C.query.all())),
                enrollments=_E.query.count(),
                reviews=_R.query.filter_by(is_approved=True).count(),
                avg_rating=round(float(_avg_rating), 2),
                satisfaction=round(float(_avg_rating) / 5 * 100) if _avg_rating else 90,
                posts=_B.query.filter_by(published=True).count(),
                stories=_SS.query.count(),
                paid_orders=__import__('models', fromlist=['Order']).Order.query.filter_by(status='paid').count(),
            )
            _stats_cache['data'] = st
            _stats_cache['t'] = now
            return st
        except Exception:
            _lexc('app.py')
            return {}
    app.jinja_env.globals['site_stats'] = site_stats

    # ---------- سیستم آیکون (Tabler — 390 آیکون در static/icons) ----------
    from icons import init_icons
    init_icons(app)

    @app.template_filter('timestamp_to_jdate')
    def _ts_jdate(ts):
        try:
            from datetime import datetime as _dt
            return jdate(_dt.fromtimestamp(int(ts)))
        except Exception:
            return '—'

    # ---------- سرو فایل‌های خصوصی آپلودی (instance/uploads) ----------
    @app.route('/uploads/<folder>/<path:filename>')
    def serve_private_upload(folder, filename):
        """سرو فایل‌های خصوصی — دسترسی قبلاً در before_request چک شده است"""
        from flask import send_from_directory as _sfd, abort as _abort
        if folder not in ('lessons', 'proofs', 'submissions', 'tickets', 'forms'):
            _abort(404)
        from uploads_helper import uploads_dir as _udir
        try:
            return _sfd(_udir(folder), filename, as_attachment=False)
        except FileNotFoundError:
            _abort(404)

    # ---------- ثبت بلوپرینت‌ها ----------
    from blueprints.site import site_bp
    from blueprints.products import products_bp
    app.register_blueprint(products_bp)

    from blueprints.auth import auth_bp
    from blueprints.shop import shop_bp
    from blueprints.student import student_bp
    from blueprints.admin_bp import admin_bp
    from blueprints.api import api_bp
    from blueprints.builder import (builder_bp, builder_courses, builder_categories,
                                    builder_posts, builder_teachers, builder_products,
                                    render_dynamic, render_shortcodes, uniq_cats)
    from models import Course as _CourseModel

    def _courses_by_id(cid):
        try:
            return _CourseModel.query.get(int(cid or 0))
        except Exception:
            return None
    app.register_blueprint(site_bp)
    app.register_blueprint(auth_bp, url_prefix='/auth')
    app.register_blueprint(shop_bp)
    app.register_blueprint(student_bp)
    app.register_blueprint(admin_bp, url_prefix='/admin')
    app.register_blueprint(api_bp, url_prefix='/api')
    app.register_blueprint(builder_bp)
    from blueprints.seo_admin import seo_bp
    app.register_blueprint(seo_bp)
    from blueprints.features import features_bp
    app.register_blueprint(features_bp)
    from blueprints.teacher import teacher_bp
    app.register_blueprint(teacher_bp)
    from blueprints.community import community_bp
    app.register_blueprint(community_bp)
    # ── ماژول‌های زیرساختی: BNPL/Cashback · مارکت‌پلیس · تعامل کاربران ──
    try:
        from bnpl import bnpl_bp
        from marketplace import market_bp
        from engagement import engage_bp
        app.register_blueprint(bnpl_bp)
        app.register_blueprint(market_bp)
        app.register_blueprint(engage_bp)
    except Exception:
        _lexc('app.py')
    # ── سرویس‌های رایگان: Clarity/Crisp/Groq/Bing ──
    try:
        from integrations import services_bp
        app.register_blueprint(services_bp)
    except Exception:
        _lexc('app.py')
    # ── نصب‌کننده وب (شبیه وردپرس — /install) ──
    try:
        from blueprints.install import install_bp
        app.register_blueprint(install_bp)
    except Exception:
        _lexc('app.py')

    # گارد نصب: اگر نصب انجام نشده، همه مسیرها → /install
    @app.before_request
    def _install_guard():
        if app.config.get('INSTALL_GUARD', True) is False:
            return None
        p = request.path
        if p.startswith('/install') or p.startswith('/static') or p == '/favicon.ico':
            return None
        from installer import is_installed as _is_inst, check_db_health as _cdh
        if not _is_inst():
            return redirect(url_for('install.wizard'))
        # نصب شده — سلامت دیتابیس؟ (جلوگیری از حلقه 500 بعد از نصب ناقص)
        ok, _msg = _cdh()
        if not ok:
            return redirect(url_for('install.wizard') + '?repair=1')
        return None
    # Flask-Admin (پنل مدیریت کامل مدل‌ها)
    try:
        from admin_panel import init_admin
        init_admin(app)
    except Exception as e:
        app.logger.warning(f'Flask-Admin غیرفعال: {e}')
    # روت پنل Flask-Admin به /admin-extra تا با پنل ما تداخل نکند
    try:
        from flask_admin import Admin as _A
        # مسیر پیش‌فرض /admin/ است — آن را به /admin-extra تغییر می‌دهیم
        # (این کار بعد از ساخت Admin انجام می‌شود؛ در admin_panel تنظیم شده)
    except Exception:
        _lexc('app.py')
    app.jinja_env.globals['builder_courses'] = builder_courses
    app.jinja_env.globals['builder_categories'] = builder_categories
    app.jinja_env.globals['builder_posts'] = builder_posts
    from blueprints.builder import (builder_price_history, builder_amazing_offer,
                                    builder_review_pro)
    app.jinja_env.globals['builder_price_history'] = builder_price_history
    app.jinja_env.globals['builder_amazing_offer'] = builder_amazing_offer
    app.jinja_env.globals['builder_review_pro'] = builder_review_pro
    app.jinja_env.globals['builder_teachers'] = builder_teachers
    app.jinja_env.globals['builder_products'] = builder_products
    app.jinja_env.globals['rd'] = render_dynamic
    app.jinja_env.globals['rshort'] = render_shortcodes
    app.jinja_env.globals['uniq_cats'] = uniq_cats
    # دسترسی ماکروها به داده‌های درخواست (ماکروها context ندارند)
    from blueprints.builder import WIDGETS as _WIDGETS
    from models import Favorite, Ticket

    def _bc_cats():
        try:
            return Category.query.order_by(Category.sort).all()
        except Exception:
            return []

    def _bc_cur():
        return getattr(g, 'user', None)

    def _bc_site():
        return getattr(g, 'settings', {})

    def _bc_fav_ids():
        u = getattr(g, 'user', None)
        if u:
            try:
                return {(u.id, f.course_id) for f in Favorite.query.filter_by(user_id=u.id).all()}
            except Exception:
                _lexc('app.py')
        return set()

    def _bc_cart():
        return len(getattr(g, 'cart', []) or [])

    def _bc_current_post():
        return getattr(g, 'current_post', None)

    def _bc_cart_total():
        try:
            from models import Course as _C
            ids = [int(i) for i in (getattr(g, 'cart', None) or [])]
            if not ids:
                return 0
            return sum(c.final_price for c in _C.query.filter(_C.id.in_(ids)).all())
        except Exception:
            return 0

    def _bc_page_settings():
        return getattr(g, 'page_settings', {})

    def _bc_reviews_pending():
        try:
            from models import Review as _R
            return _R.query.filter_by(is_approved=False).count()
        except Exception:
            return 0

    def _bc_tickets():
        u = getattr(g, 'user', None)
        if u:
            try:
                return Ticket.query.filter(Ticket.user_id == u.id,
                                           Ticket.status.in_(['open', 'answered'])).count()
            except Exception:
                _lexc('app.py')
        return 0

    # ---------- کش TTL ساده برای ویجت‌های دیتامحور (کاهش کوئری‌ها) ----------
    import threading as _cache_thr
    _cache_lock = _cache_thr.Lock()
    _cache_store = {}

    def _ttl_cache(key, ttl, fn):
        now = _time.time()
        with _cache_lock:
            hit = _cache_store.get(key)
            if hit and now - hit[0] < ttl:
                return hit[1]
        val = fn()
        with _cache_lock:
            _cache_store[key] = (now, val)
            if len(_cache_store) > 200:
                _cache_store.clear()
        return val

    def _load_success_stories():
        def _q():
            from models import SuccessStory
            return SuccessStory.query.filter_by(is_active=True) \
                .order_by(SuccessStory.sort, SuccessStory.id.desc()).limit(6).all()
        try:
            g._success_stories = _ttl_cache('stories', 60, _q)
            return g._success_stories
        except Exception:
            return []

    def _load_reviews():
        def _q():
            from models import Review
            return Review.query.filter_by(is_approved=True) \
                .order_by(Review.created_at.desc()).limit(9).all()
        try:
            return _ttl_cache('reviews', 60, _q)
        except Exception:
            return []

    def _load_exam_cats():
        def _q():
            from models import QuestionBank
            return [r[0] for r in db.session.query(QuestionBank.category)
                    .distinct().order_by(QuestionBank.category).all() if r[0]]
        try:
            return _ttl_cache('exam_cats', 300, _q)
        except Exception:
            return []

    app.jinja_env.globals.update(
        WIDGETS=_WIDGETS, bc_categories=_bc_cats, bc_cur_user=_bc_cur,
        bc_site=_bc_site, bc_fav_ids=_bc_fav_ids, bc_cart_count=_bc_cart,
        bc_tickets_count=_bc_tickets, bc_current_post=_bc_current_post,
        bc_cart_total=_bc_cart_total, courses_by_id=_courses_by_id,
        bc_reviews_pending=_bc_reviews_pending,
        bc_page_settings=_bc_page_settings,
        bc_current_course=lambda: getattr(g, 'current_course', None),
        bc_current_teacher=lambda: getattr(g, 'current_teacher', None),
        bc_success_stories=lambda: getattr(g, '_success_stories', None) or _load_success_stories(),
        bc_reviews=lambda: _load_reviews(),
        bc_exam_cats=lambda: _load_exam_cats())

    # ---------- هدرهای امنیتی + فشرده‌سازی ----------
    @app.after_request
    def security_headers(resp):
        resp.headers.setdefault('X-Content-Type-Options', 'nosniff')
        resp.headers.setdefault('X-Frame-Options', 'SAMEORIGIN')
        resp.headers.setdefault('Referrer-Policy', 'strict-origin-when-cross-origin')
        resp.headers.setdefault('X-Powered-By', 'Academy LMS')
        # محدودسازی APIهای مرورگر (دوربین/میکروفون/موقعیت) — فقط در صورت نیاز باز شوند
        resp.headers.setdefault('Permissions-Policy', 'camera=(), microphone=(), geolocation=()')
        # ایزوله‌سازی پنجره‌های کراس‌اورجین
        resp.headers.setdefault('Cross-Origin-Opener-Policy', 'same-origin')
        # HSTS — فقط روی HTTPS فعال می‌شود
        if request.is_secure:
            resp.headers.setdefault('Strict-Transport-Security', 'max-age=31536000; includeSubDomains')
        # کش هوشمند: استاتیک ۷ روز، HTML بدون کش
        if request.path.startswith('/static/'):
            resp.headers['Cache-Control'] = 'public, max-age=604800, immutable'
        elif resp.content_type and resp.content_type.startswith('text/html'):
            resp.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
        csp = (
            "default-src 'self'; "
            "script-src 'self' 'unsafe-inline' https://www.googletagmanager.com https://www.youtube-nocookie.com https://www.aparat.com https://w.soundcloud.com; "
            "style-src 'self' 'unsafe-inline'; "
            "img-src 'self' data: https:; "
            "frame-src 'self' https://www.youtube-nocookie.com https://www.youtube.com https://www.aparat.com https://player.vimeo.com https://w.soundcloud.com https://maps.google.com; "
            "font-src 'self' data:; "
            "connect-src 'self' https://www.google-analytics.com"
        )
        if resp.status_code != 500:
            resp.headers.setdefault('Content-Security-Policy', csp)
        # فشرده‌سازی gzip برای HTML، CSS و JS
        import gzip as _gzip
        _ct = resp.content_type or ''
        _compressible = _ct.startswith('text/html') or _ct.startswith('text/css') or \
                        _ct.startswith('application/javascript') or _ct.startswith('text/javascript') or \
                        _ct.startswith('application/json')
        if (resp.status_code == 200 and _compressible):
            try:
                _data = resp.get_data()
            except RuntimeError:
                # فایل‌های static در حالت passthrough — خروج از حالت برای خواندن داده
                resp.direct_passthrough = False
                _data = resp.get_data()
            if len(_data) > 500:
                accept = request.headers.get('Accept-Encoding', '')
                if 'gzip' in accept:
                    compressed = _gzip.compress(_data, 6)
                    if len(compressed) < len(_data):
                        resp.set_data(compressed)
                        resp.headers['Content-Encoding'] = 'gzip'
                        resp.headers['Content-Length'] = str(len(compressed))
        # کش خصوصی کوتاه‌مدت برای صفحات عمومی مهمان (فقط مرورگر همان کاربر)
        # — سرعت بازدیدهای تکراری بدون خطر لو رفتن سشن/توکن بین کاربران
        if (resp.status_code == 200 and _ct.startswith('text/html') and
                request.method == 'GET' and not getattr(g, 'user', None) and
                request.path.startswith(('/course/', '/courses', '/blog', '/about', '/faq',
                                         '/contact', '/terms', '/privacy', '/teachers', '/',
                                         '/bundles', '/success-stories', '/learning-paths',
                                         '/teachers', '/faq'))):
            # صفحه اصلی و لیست‌ها: کش ۳۰۰ ثانیه (همان کاربر) — سرعت بازدید تکراری
            _age = 300 if request.path == '/' else 120
            resp.headers['Cache-Control'] = f'private, max-age={_age}'
        return resp

    # ---------- Rate limit بر اساس IP — Redis در production، حافظه در dev ----------
    import threading as _thr, time as _time
    _rl_lock = _thr.Lock()
    _rl_hits = {}  # ip -> [window_start, count]  (fallback درون‌حافظه)
    _rl_redis = None
    try:
        if os.environ.get('REDIS_URL'):
            import redis as _redis
            _rl_redis = _redis.Redis.from_url(os.environ['REDIS_URL'], socket_timeout=2, socket_connect_timeout=2)
            _rl_redis.ping()
            app.logger.info('rate limit: Redis فعال شد')
    except Exception:
        _rl_redis = None
        app.logger.info('rate limit: حالت حافظه داخلی (REDIS_URL تنظیم نشده)')

    _TRUST_PROXY = os.environ.get('TRUST_PROXY') == '1'

    def _client_ip():
        """IP واقعی — فقط وقتی TRUST_PROXY=1 به X-Forwarded-For اعتماد کن (nginx آن را overwrite میکند)"""
        if _TRUST_PROXY:
            return request.headers.get('X-Forwarded-For', request.remote_addr or 'unknown').split(',')[0].strip()
        return request.remote_addr or 'unknown'

    def _rate_limit(limit, window):
        ip = _client_ip()
        now = _time.time()
        if _rl_redis is not None:
            try:
                key = f'rl:{ip}:{request.path[:60]}'
                n = _rl_redis.incr(key)
                if n == 1:
                    _rl_redis.expire(key, window)
                return n <= limit
            except Exception:
                pass  # در صورت خطای Redis → fallback به حافظه
        with _rl_lock:
            rec = _rl_hits.get(ip)
            if not rec or now - rec[0] > window:
                _rl_hits[ip] = [now, 1]
                return True
            rec[1] += 1
            if rec[1] > limit:
                return False
            # پاک‌سازی دوره‌ای حافظه
            if len(_rl_hits) > 5000:
                _rl_hits.clear()
            return True

    @app.before_request
    def rate_limit_protect():
        p = request.path
        if p.startswith('/api/') or p.startswith('/builder/api/'):
            if not _rate_limit(120, 60):
                return 'درخواست بیش از حد — کمی صبر کنید.', 429
        elif p == '/auth/login' and request.method == 'POST':
            if not _rate_limit(20, 300):
                return 'تلاش بیش از حد — ۵ دقیقه صبر کنید.', 429
        elif p in ('/auth/register', '/auth/phone-send') and request.method == 'POST':
            if not _rate_limit(10, 300):
                return 'درخواست بیش از حد — کمی صبر کنید.', 429
        elif p == '/newsletter' and request.method == 'POST':
            if not _rate_limit(5, 60):
                return 'درخواست بیش از حد — کمی صبر کنید.', 429
        return None

    # ---------- CSRF محافظت (توکن دستی در سشن) ----------
    @app.before_request
    def csrf_protect():
        import secrets as _secrets
        if '_csrf_token' not in session:
            session['_csrf_token'] = _secrets.token_hex(16)
        g.csrf_token = session['_csrf_token']
        # بررسی POST های حساس (بدون API که JSON دارد؛ نصب‌کننده هم گارد خودش را دارد)
        if request.method == 'POST' and not request.path.startswith('/api') and \
                not request.path.startswith('/builder/api') and \
                not request.path.startswith('/install'):
            token = request.form.get('_csrf_token') or request.headers.get('X-CSRF-Token')
            if not token or token != session.get('_csrf_token'):
                abort(400, description='توکن CSRF نامعتبر است. صفحه را رفرش کنید.')

    # ---------- GET روی مسیرهای POST-only → ریدایرکت به جای 405 ----------
    @app.errorhandler(400)
    def bad_request(e):
        return render_error('درخواست نامعتبر', 'فرم یا درخواست ارسال‌شده معتبر نیست — صفحه را رفرش کنید.', 400)

    @app.errorhandler(413)
    def too_large(e):
        return render_error('حجم فایل زیاد است', 'حداکثر حجم مجاز آپلود ۵۰ مگابایت است.', 413)

    @app.errorhandler(405)
    def method_not_allowed(e):
        if request.path.startswith('/install'):
            from flask import jsonify as _j
            return _j(ok=False, msg='روش درخواست نامعتبر است', code=405), 405
        p = request.path
        prefix_map = [
            ('/admin/gateways', 'admin.gateways'), ('/admin/messengers', 'admin.messengers'),
            ('/admin/lesson-questions', 'admin.lesson_questions'), ('/admin/submissions', 'admin.submissions'),
            ('/admin/pages', 'admin.pages'), ('/admin/users', 'admin.users'), ('/admin/proofs', 'admin.proofs'),
            ('/admin/payouts', 'admin.payouts'), ('/admin/certificates', 'admin.certificates'),
            ('/admin/bundles', 'admin.bundles'), ('/admin/courses', 'admin.courses'),
            ('/admin/quizzes', 'admin.quizzes'), ('/admin/canned-replies', 'admin.canned_replies'),
            ('/admin/forum', 'admin.forum_moderate'), ('/admin/forms', 'admin.forms'),
            ('/admin/live-sessions', 'admin.live_sessions'), ('/admin/backup', 'admin.backup_list'),
            ('/admin/success-stories', 'admin.success_stories'), ('/admin/assignments', 'admin.assignments'),
            ('/admin/notifications', 'admin.admin_notifications'), ('/admin/newsletters', 'admin.newsletters'),
            ('/admin/menus', 'admin.menus'), ('/admin/tickets', 'admin.tickets'),
            ('/admin/reports', 'admin.overview'), ('/admin/', 'admin.overview'),
            ('/builder', 'builder.index'), ('/lesson/', 'student.my_courses'),
            ('/dashboard/', 'student.dashboard'), ('/talent-test', 'features.talent_test'),
            ('/community', 'community.forum'), ('/teacher-panel', 'teacher.dashboard'),
            ('/exam/', 'features.exam_practice'), ('/wallet/', 'features.wallet'),
            ('/pay/', 'shop.cart'), ('/course/', 'site.courses'), ('/feedback/', 'student.my_courses'),
            ('/api/', 'site.index'), ('/form/', 'site.index'),
        ]
        for prefix, ep in prefix_map:
            if p.startswith(prefix):
                try:
                    return redirect(url_for(ep))
                except Exception:
                    _lexc('app.py')
        ref = request.referrer or ''
        if ref.startswith(request.host_url):
            return redirect(ref)
        return redirect('/')

    # ---------- قبل از هر درخواست ----------
    @app.before_request
    def load_globals():
        # پنل‌های مدیریتی مستقل از سایت — بدون هدر/فوتر فروشگاه
        g.hide_hdr = False
        g.hide_ftr = False
        _p = request.path
        if _p.startswith('/admin') or _p.startswith('/teacher-panel') or _p.startswith('/builder'):
            g.hide_hdr = True
            g.hide_ftr = True
        g.settings = {}
        try:
            for s in Setting.query.all():
                g.settings[s.key] = s.value
        except Exception:
            _lexc('app.py')
        # بکاپ خودکار دیتابیس: هر ۲۴ ساعت یک نسخه، نگهداری ۷ نسخه
        try:
            import os as _os
            bk_dir = _os.path.join(app.instance_path, 'backups')
            _os.makedirs(bk_dir, exist_ok=True)
            import glob as _glob, shutil as _shutil
            bks = sorted(_glob.glob(_os.path.join(bk_dir, 'academy-*.db')), key=_os.path.getmtime)
            need = True
            if bks:
                import time as _time
                need = (_time.time() - _os.path.getmtime(bks[-1])) > 86400
            if need:
                from datetime import datetime as _dt
                _shutil.copy2(_os.path.join(app.instance_path, 'academy.db'),
                              _os.path.join(bk_dir, f'academy-{_dt.now():%Y%m%d-%H%M}.db'))
                for old_bk in bks[:-7]:
                    try:
                        _os.remove(old_bk)
                    except Exception:
                        _lexc('app.py')
        except Exception:
            _lexc('app.py')
        # صفحات صفحه‌ساز (هدر، فوتر، منوی موبایل، خانه...)
        g.pages = {}
        g.page_custom_header = None
        g.page_custom_footer = None
        try:
            from models import Page
            # انتشار خودکار صفحات زمان‌بندی‌شده
            try:
                due = Page.query.filter(Page.publish_at.isnot(None),
                                        Page.publish_at <= utcnow()).all()
                for p in due:
                    p.is_published = True
                    p.publish_at = None
                if due:
                    db.session.commit()
            except Exception:
                _lexc('app.py')
            for p in Page.query.all():
                g.pages[p.ptype] = p
        except Exception:
            _lexc('app.py')
        g.user = None
        uid = session.get('uid')
        if uid:
            g.user = db.session.get(User, uid)
            if g.user and not g.user.is_active:
                session.clear()
                g.user = None
            elif g.user and session.get('st') and g.user.session_token and session['st'] != g.user.session_token:
                # سشن از دستگاه دیگری باطل شده است (خروج از همه دستگاه‌ها)
                session.clear()
                g.user = None
                from flask import flash as _flash
                _flash('سشن شما در دستگاه دیگری بسته شد. دوباره وارد شوید.', 'info')
        daily_reminders()
        # ---------- حفاظت از فایل‌های خصوصی (uploads) ----------
        # مسیرهای جدید /uploads/... و قدیمی /static/uploads/... هر دو چک می‌شوند
        _p = request.path
        _uploads_prefix = '/static/uploads/' if _p.startswith('/static/uploads/') else                           ('/uploads/' if _p.startswith('/uploads/') else None)
        if _uploads_prefix:
            _rel = _p[len(_uploads_prefix):]
            _folder = _rel.split('/')[0] if '/' in _rel else _rel
            if _folder not in ('lessons', 'proofs', 'submissions', 'tickets', 'forms'):
                return None  # media و opt عمومی هستند
            if not g.user:
                return redirect(url_for('auth.login', next=_p))
            try:
                from models import (Lesson as _L, PaymentProof as _Pr, AssignmentSubmission as _As,
                                    Ticket as _T, TicketReply as _Tr, Assignment as _Asg,
                                    Enrollment as _En, Course as _Co, CourseTeacher as _Ct)
                if _folder == 'lessons':
                    _fname = _rel.split('/')[-1]
                    # جستجو با نام فایل — مسیر ذخیره‌شده ممکن است قدیمی/جدید باشد
                    _les_all = _L.query.filter(_L.file_url.like('%/' + _fname)).all()
                    if _les_all and (g.user.is_admin or any(
                            _En.query.filter_by(user_id=g.user.id,
                                                course_id=_l.section.course_id).first()
                            for _l in _les_all)):
                        return None
                elif _folder == 'proofs':
                    _fname = _rel.split('/')[-1]
                    _proof = _Pr.query.filter_by(file=_fname).first()
                    if _proof:
                        _ord = db.session.get(Order, _proof.order_id)
                        if g.user.is_admin or (_ord and _ord.user_id == g.user.id):
                            return None
                elif _folder == 'submissions':
                    _fname = _rel.split('/')[-1]
                    _sub = _As.query.filter_by(file=_fname).first()
                    if _sub:
                        if g.user.id == _sub.user_id or g.user.is_admin:
                            return None
                        _asg = db.session.get(_Asg, _sub.assignment_id)
                        if _asg:
                            _c = db.session.get(_Co, _asg.course_id)
                            if _c and (_c.teacher_id == g.user.id or
                                       _Ct.query.filter_by(course_id=_asg.course_id, teacher_id=g.user.id).first()):
                                return None
                elif _folder == 'tickets':
                    _fname = _rel.split('/')[-1]
                    _t = _T.query.filter_by(attachment=_fname).first()
                    _tr = _Tr.query.filter_by(attachment=_fname).first()
                    if _t and (g.user.is_admin or _t.user_id == g.user.id):
                        return None
                    if _tr and (g.user.is_admin or (_tr.ticket and _tr.ticket.user_id == g.user.id)):
                        return None
                elif _folder == 'forms':
                    if g.user.is_admin:
                        return None
            except Exception:
                _lexc('app.py')
            # پاسخ ساده 403 — بدون قالب (context processor ها هنوز اجرا نشده‌اند)
            from flask import Response as _Resp
            return _Resp('دسترسی غیرمجاز', status=403)
                # ریدایرکت‌های 301 (مدیریت‌شده از پنل سئو)
        if not request.path.startswith('/static/') and not request.path.startswith('/builder/api'):
            try:
                from models import RedirectRule
                rule = RedirectRule.query.filter_by(source=request.path, is_active=True).first()
                if rule:
                    return redirect(rule.target, code=rule.code or 301)
            except Exception:
                _lexc('app.py')
        # حالت تعمیرات: فقط ادمین می‌تواند وارد شود
        if g.settings.get('maintenance') == '1' and not (g.user and g.user.is_admin):
            allowed = request.path.startswith('/static') or \
                request.endpoint in ('site.maintenance', 'auth.login', 'auth.logout') or \
                (request.endpoint or '').startswith('admin')
            if not allowed:
                return redirect(url_for('site.maintenance'))
        if g.user and not g.user.profile_complete() and request.endpoint and \
                request.endpoint.startswith('student.') and request.endpoint != 'student.profile':
            # کاربرانی که با شماره تماس وارد شده‌اند باید پروفایل را کامل کنند
            return redirect(url_for('auth.complete_profile'))
        # انتخاب تم — طراحی کلی سایت (site_design) برنده است مگر پیش‌فرض (۱)
        from designs import SITE_DESIGNS
        theme = None
        # پیش‌نمایش طرح با پارامتر URL (مثلا ?site_design=pd-05) — فقط برای بازدید
        _pv = request.args.get('site_design', '')
        sd = _pv if _pv in SITE_DESIGNS else g.settings.get('site_design', '1')
        if sd == '1' or sd not in SITE_DESIGNS:
            if g.user:
                theme = g.user.theme
            if not theme:
                theme = request.cookies.get('lms_theme')
            if not theme or theme not in VALID_THEMES:
                theme = g.settings.get('default_theme', 'theme-01')
        else:
            theme = SITE_DESIGNS[sd]['theme']
        if theme not in VALID_THEMES:
            theme = 'theme-01'
        g.theme = theme
        # رنگ مرورگر (theme-color) — برای طرح‌های ایرانی از پالت آن‌ها
        g.theme_color = None
        if theme.startswith('pd-'):
            try:
                from persian_themes import get_theme as _gt
                _t = _gt(theme)
                if _t:
                    g.theme_color = _t['colors']['primary']
            except Exception:
                pass
        # مقادیر مؤثر طراحی (کانتینر و شعاع گوشه)
        g.eff_container = g.settings.get('kit_container') or ''
        g.eff_radius = g.settings.get('kit_radius') or ''
        if not g.eff_container and sd in SITE_DESIGNS:
            g.eff_container = SITE_DESIGNS[sd]['container']
        if not g.eff_radius and sd in SITE_DESIGNS:
            g.eff_radius = SITE_DESIGNS[sd]['radius']
        # سبد خرید
        g.cart = session.get('cart', [])
        g.cart_count = len(g.cart)
        # موتور سئو (بعد از بارگذاری تنظیمات)
        from models import SeoMeta
        g.seo = dict(title='', description='', keywords='', canonical='', noindex=False,
                     og_image='', og_type='website', schema=None)
        try:
            path = request.path
            m = SeoMeta.query.filter_by(path=path).first()
            if m:
                g.seo['title'] = m.title or ''
                g.seo['description'] = m.description or ''
                g.seo['keywords'] = m.keywords or ''
                g.seo['canonical'] = m.canonical or ''
                g.seo['noindex'] = bool(m.noindex)
                g.seo['og_image'] = m.og_image or ''
            if not g.seo['title']:
                g.seo['title'] = g.settings.get('seo_title', '')
            if not g.seo['description']:
                g.seo['description'] = g.settings.get('seo_desc', '')
            g.seo['keywords'] = g.seo['keywords'] or g.settings.get('seo_keywords', '')
            if not g.seo['og_image']:
                g.seo['og_image'] = g.settings.get('seo_og_image', 'hero.png')
            if not g.seo['canonical']:
                g.seo['canonical'] = request.base_url.split('?')[0]
            if request.endpoint and (request.endpoint.startswith('admin') or
                                     request.endpoint.startswith('builder')):
                g.seo['noindex'] = True
        except Exception:
            _lexc('app.py')
    def daily_reminders():
        """یادآوری‌های روزانه: آزمون نزدیک، کلاس نزدیک، خرید ناقص (در قبل از هر درخواست با احتمال کم)"""
        try:
            import random as _r
            if _r.random() > 0.05:
                return
            from datetime import timedelta as _td
            from models import LiveSession, Quiz, Order, Notification, Enrollment
            # کلاس‌های ۲۴ ساعت آینده
            soon = LiveSession.query.filter(
                LiveSession.starts_at >= utcnow(),
                LiveSession.starts_at <= utcnow() + _td(hours=24)).all()
            for ls in soon:
                students = Enrollment.query.filter_by(course_id=ls.course_id).all() if ls.course_id else []
                for en in students:
                    Notification.notify(en.user_id, 'کلاس آنلاین به‌زودی 🎥',
                                        f'«{ls.title}» شروع می‌شود — لینک ورود فعال است.', '🎥',
                                        url_for('community.live'))
            # سفارش‌های ناقص (۲۴+ ساعت)
            pending = Order.query.filter(Order.status == 'pending',
                                         Order.created_at <= utcnow() - _td(hours=24)).all()
            for o in pending:
                Notification.notify(o.user_id, 'خرید شما ناتمام مانده 🛒',
                                    f'سفارش {o.code} هنوز پرداخت نشده — با تخفیف فعلی تکمیلش کن!',
                                    '🛒', url_for('shop.pay_start', code=o.code))
            db.session.commit()
        except Exception:
            _lexc('app.py')
    @app.context_processor
    def inject_helpers():
        def log_activity(action, detail=''):
            """ثبت رویداد در لاگ فعالیت — از قالب‌ها و routeها قابل فراخوانی"""
            try:
                from models import ActivityLog
                db.session.add(ActivityLog(
                    user_id=g.user.id if g.user else None,
                    action=action, detail=detail[:280],
                    ip=request.headers.get('X-Forwarded-For', request.remote_addr or '')[:60]))
                db.session.commit()
            except Exception:
                db.session.rollback()
        return dict(log_activity=log_activity)

    @app.context_processor
    def inject_captcha():
        """کادر کپچای ضداسپم برای فرم‌های عمومی"""
        from captcha import current_captcha
        from markupsafe import Markup
        def captcha_box():
            text = current_captcha()
            return Markup(
                '<div class="form-group">'
                '<label for="cap_inp">🧮 سوال امنیتی: <b>' + text + '</b></label>'
                '<input id="cap_inp" class="form-control" name="captcha" required dir="ltr" '
                'style="max-width:180px" autocomplete="off" placeholder="پاسخ">'
                '<input type="text" name="hp_website" value="" tabindex="-1" autocomplete="off" '
                'aria-hidden="true" style="position:absolute;left:-9999px;opacity:0;height:0">'
                '</div>')
        return dict(captcha_box=captcha_box)

    @app.context_processor
    def inject_globals():
        # اسکریپت‌های سرویس‌های رایگان (Clarity/Crisp) — از .env
        try:
            from integrations import clarity_script, crisp_script
            _clarity = clarity_script()
            _crisp = crisp_script()
        except Exception:
            _clarity, _crisp = '', ''
        cats = []
        fav_ids = set()
        enrolled_ids = set()
        try:
            cats = Category.query.order_by(Category.sort, Category.id).all()
            if getattr(g, 'user', None):
                from models import Favorite, Enrollment
                _u0 = g.user
                fav_ids = {(_u0.id, f.course_id) for f in
                           Favorite.query.filter_by(user_id=_u0.id).all()}
                enrolled_ids = {e.course_id for e in
                                Enrollment.query.filter_by(user_id=_u0.id).all()}
        except Exception:
            _lexc('app.py')
        from gamification import user_badges
        from permissions import has_permission, ROLES
        unread_count = 0
        _u = getattr(g, 'user', None)
        if _u:
            try:
                from models import Notification
                unread_count = Notification.query.filter_by(user_id=_u.id, is_read=False).count()
            except Exception:
                pass
        return dict(site=getattr(g, 'settings', {}), cur_user=_u, site_categories=cats,
                    unread_notifications=unread_count,
                    current_role=(ROLES.get(_u.role, {}).get('fa') if _u else ''),
                    has_perm=has_permission,
                    my_badges=user_badges(_u) if _u else [],
                    cart_ids=getattr(g, 'cart', []), cart_count=getattr(g, 'cart_count', 0),
                    theme=getattr(g, 'theme', 'theme-01'),
                    fav_ids=fav_ids, now=utcnow(), builder_pages=getattr(g, 'pages', {}),
                    enrolled_ids=enrolled_ids,
                    eff_container=getattr(g, 'eff_container', ''),
                    eff_radius=getattr(g, 'eff_radius', ''),
                    csrf_token=getattr(g, 'csrf_token', ''),
                    clarity_script=_clarity, crisp_script=_crisp,
                    bc_admin_menu=lambda: __import__('permissions', fromlist=['menu_for']).menu_for(_u),
                    seo=getattr(g, 'seo', dict(title='', description='', keywords='',
                                               canonical='', noindex=False, og_image='',
                                               og_type='website', schema=None)))

    # ---------- خطاها ----------
    @app.errorhandler(404)
    def not_found(e):
        # مسیرهای نصب: همیشه JSON (مرورگر نصب‌کننده هرگز HTML نمی‌گیرد)
        if request.path.startswith('/install'):
            from flask import jsonify as _j
            return _j(ok=False, msg='مسیر نصب یافت نشد', code=404), 404
        # ثبت 404 در مانیتور (ردیابی لینک‌های شکسته)
        try:
            if not request.path.startswith('/static/') and not request.path.startswith('/api'):
                from models import NotFoundLog
                log = NotFoundLog.query.filter_by(path=request.path).first()
                if log:
                    log.count += 1
                    log.referrer = request.referrer or log.referrer
                else:
                    db.session.add(NotFoundLog(path=request.path[:300],
                                               referrer=(request.referrer or '')[:400]))
                db.session.commit()
        except Exception:
            _lexc('app.py')
        # اگر صفحه ۴۰۴ با صفحه‌ساز ساخته شده باشد
        try:
            from models import Page as _P
            ep = _P.query.filter_by(ptype='404', is_published=True).first()
            if ep and ep.rows():
                from flask import render_template as _rt
                g.page_settings = ep.settings()
                return _rt('builder/public.html', page=ep), 404
        except Exception:
            _lexc('app.py')
        return render_template('errors/standalone_error.html',
                               err_title='صفحه مورد نظر پیدا نشد',
                               err_msg='آدرس وارد شده اشتباه است یا حذف شده است.',
                               err_code=404), 404

    @app.errorhandler(403)
    def forbidden(e):
        return render_template('errors/standalone_error.html',
                               err_title='دسترسی غیرمجاز',
                               err_msg='شما اجازه دسترسی به این بخش را ندارید.',
                               err_code=403), 403

    @app.errorhandler(500)
    def server_error(e):
        # ثبت کامل traceback در فایل لاگ — بدون لو دادن جزئیات به کاربر
        try:
            import traceback as _tb
            app.logger.error('500 Internal Server Error: %s\n%s',
                             e, _tb.format_exc())
        except Exception:
            pass
        # قالب مستقل — چون خطای 500 اغلب از دیتابیس است و base.html به دیتابیس نیاز دارد
        return render_template('errors/standalone_error.html',
                               err_title='خطای سرور',
                               err_msg='مشکلی در سرور رخ داده است. لطفاً کمی بعد تلاش کنید.',
                               err_code=500), 500

    def render_error(title, msg, code):
        from flask import render_template
        return render_template('errors/error.html', err_title=title, err_msg=msg,
                               err_code=code), code

    return app


app = create_app()

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(host='0.0.0.0', port=5000, debug=True)

